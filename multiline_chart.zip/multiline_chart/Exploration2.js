// Set the margins
var margin = { top: 60, right: 100, bottom: 20, left: 80 },
    width = 850 - margin.left - margin.right,
    height = 370 - margin.top - margin.bottom;

// Parse the month variable
var parseMonth = d3.timeParse("%b");
var formatMonth = d3.timeFormat("%b");

// Set the ranges
var x = d3.scaleTime().domain([parseMonth("Jan"), parseMonth("Dec")]).range([0, width]);
var y = d3.scaleLinear().range([height, 0]);

// Define the line
var valueLine = d3.line()
    .x(function (d) { return x(d.Month); })
    .y(function (d) { return y(+d.Sales); })

// Create the svg canvas in the "graph" div
var svg = d3.select("#graph")
    .append("svg")
    .style("width", width + margin.left + margin.right + "px")
    .style("height", height + margin.top + margin.bottom + "px")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
    .attr("class", "svg");

// Import the CSV data
// d3.json("Example2.json", function (error, data) {
    // if (error) throw error;

    data = [
        {
          "Month": "Jan",
          "Sales": 87,
          "Fruit": "strawberry"
        },
        {
          "Month": "Feb",
          "Sales": 3,
          "Fruit": "strawberry"
        },
        {
          "Month": "Mar",
          "Sales": 89,
          "Fruit": "strawberry"
        },
        {
          "Month": "Apr",
          "Sales": 56,
          "Fruit": "strawberry"
        },
        {
          "Month": "May",
          "Sales": 1,
          "Fruit": "strawberry"
        },
        {
          "Month": "Jun",
          "Sales": 17,
          "Fruit": "strawberry"
        },
        {
          "Month": "Jul",
          "Sales": 59,
          "Fruit": "strawberry"
        },
        {
          "Month": "Aug",
          "Sales": 43,
          "Fruit": "strawberry"
        },
        {
          "Month": "Sep",
          "Sales": 16,
          "Fruit": "strawberry"
        },
        {
          "Month": "Oct",
          "Sales": 94,
          "Fruit": "strawberry"
        },
        {
          "Month": "Nov",
          "Sales": 99,
          "Fruit": "strawberry"
        },
        {
          "Month": "Dec",
          "Sales": 53,
          "Fruit": "strawberry"
        },
        {
          "Month": "Jan",
          "Sales": 93,
          "Fruit": "grape"
        },
        {
          "Month": "Feb",
          "Sales": 8,
          "Fruit": "grape"
        },
        {
          "Month": "Mar",
          "Sales": 95,
          "Fruit": "grape"
        },
        {
          "Month": "Apr",
          "Sales": 62,
          "Fruit": "grape"
        },
        {
          "Month": "May",
          "Sales": 5,
          "Fruit": "grape"
        },
        {
          "Month": "Jun",
          "Sales": 24,
          "Fruit": "grape"
        },
        {
          "Month": "Jul",
          "Sales": 62,
          "Fruit": "grape"
        },
        {
          "Month": "Aug",
          "Sales": 49,
          "Fruit": "grape"
        },
        {
          "Month": "Sep",
          "Sales": 18,
          "Fruit": "grape"
        },
        {
          "Month": "Oct",
          "Sales": 101,
          "Fruit": "grape"
        },
        {
          "Month": "Nov",
          "Sales": 103,
          "Fruit": "grape"
        },
        {
          "Month": "Dec",
          "Sales": 53,
          "Fruit": "grape"
        },
        {
          "Month": "Jan",
          "Sales": 94,
          "Fruit": "blueberry"
        },
        {
          "Month": "Feb",
          "Sales": 15,
          "Fruit": "blueberry"
        },
        {
          "Month": "Mar",
          "Sales": 95,
          "Fruit": "blueberry"
        },
        {
          "Month": "Apr",
          "Sales": 64,
          "Fruit": "blueberry"
        },
        {
          "Month": "May",
          "Sales": 11,
          "Fruit": "blueberry"
        },
        {
          "Month": "Jun",
          "Sales": 33,
          "Fruit": "blueberry"
        },
        {
          "Month": "Jul",
          "Sales": 64,
          "Fruit": "blueberry"
        },
        {
          "Month": "Aug",
          "Sales": 53,
          "Fruit": "blueberry"
        },
        {
          "Month": "Sep",
          "Sales": 27,
          "Fruit": "blueberry"
        },
        {
          "Month": "Oct",
          "Sales": 103,
          "Fruit": "blueberry"
        },
        {
          "Month": "Nov",
          "Sales": 108,
          "Fruit": "blueberry"
        },
        {
          "Month": "Dec",
          "Sales": 62,
          "Fruit": "blueberry"
        }
      ]

    // Format the data
    data.forEach(function (d) {
        d.Month = parseMonth(d.Month);
        d.Sales = +d.Sales;
        d.Fruit = d.Fruit;
    });

    var nest = d3.nest()
        .key(function (d) {
            return d.Fruit;
        })
        .entries(data)

    // Scale the range of the data
    x.domain(d3.extent(data, function (d) { return d.Month; }));
    y.domain([0, d3.max(data, function (d) { return d.Sales; })]);

    // Set up the x axis
    var xaxis = svg.append("g")
        .attr("transform", "translate(0," + height + ")")
        .attr("class", "x axis")
        .call(d3.axisBottom(x)
            .ticks(d3.timeMonth)
            .tickSize(0, 0)
            .tickFormat(d3.timeFormat("%B"))
            .tickSizeInner(0)
            .tickPadding(10));

    // Add the Y Axis
    var yaxis = svg.append("g")
        .attr("class", "y axis")
        .call(d3.axisLeft(y)
            .ticks(5)
            .tickSizeInner(0)
            .tickPadding(6)
            .tickSize(0, 0));

    // yaxis.select(".domain").style("display","none")

    // Add a label to the y axis
    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - 60)
        .attr("x", 0 - (height / 2))
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .text("Monthly Sales")
        .attr("class", "y axis label");

    // Draw the line
    svg.selectAll(".line")
        .data(nest)
        .enter()
        .append("path")
        .attr("class", "line")
        .attr("d", function (d) {
            return valueLine(d.values)
        });

// })